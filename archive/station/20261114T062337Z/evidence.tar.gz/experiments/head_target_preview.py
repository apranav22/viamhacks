"""Read-only estimate of socket-screw head target in saved top frames."""
import json
import sys
from pathlib import Path
import numpy as np
from PIL import Image
from scipy import ndimage
from screws import WristView


def head_target(img, bbox, meta, table_z=6.5):
    x0, y0, x1, y1 = bbox
    margin = 25
    X0, Y0 = max(0, x0-margin), max(0, y0-margin)
    a = np.asarray(img.crop((X0,Y0,min(img.width,x1+margin), min(img.height,y1+margin))), dtype=float)
    chroma = (a[:,:,0]-a[:,:,2])/np.maximum(a.sum(2),1)
    border = np.r_[chroma[:4].ravel(),chroma[-4:].ravel(),chroma[:,:4].ravel(),chroma[:,-4:].ravel()]
    background = max(float(np.percentile(border,75)),0.08)
    mask = chroma < background * 0.3
    mask = ndimage.binary_fill_holes(ndimage.binary_closing(ndimage.binary_opening(mask),iterations=2))
    labels, count = ndimage.label(mask)
    overlap = np.zeros_like(mask)
    overlap[y0-Y0:y1-Y0,x0-X0:x1-X0] = True
    areas = ndimage.sum(overlap, labels, np.arange(1,count+1))
    if not len(areas): raise ValueError('no object mask')
    mask = labels == np.argmax(areas)+1
    ys, xs = np.where(mask)
    pts = np.array([xs,ys]).T.astype(float)
    c = pts.mean(0)
    eigenvalues, eigenvectors = np.linalg.eigh(np.cov((pts-c).T))
    ax = eigenvectors[:, -1]
    along = (pts-c)@ax
    perp = (pts-c)@np.array([-ax[1],ax[0]])
    edges = np.quantile(along,[0.01,0.99]); length=edges[1]-edges[0]
    # Compare cross-section widths in the two ends; require a demonstrably wider head.
    buckets=[]
    for lo,hi in [(0.02,0.14),(0.86,0.98)]:
        sel=(along > edges[0]+lo*length)&(along < edges[0]+hi*length)
        buckets.append(np.quantile(perp[sel],.9)-np.quantile(perp[sel],.1))
    head_left=buckets[0]>buckets[1]
    ratio=max(buckets)/max(1,min(buckets))
    # 4% from the wider end lands on the head itself, not the narrow neck (8% grip remained near-empty).
    distance=edges[0]+(.04 if head_left else .96)*length
    select=np.abs(along-distance)<max(3,length*.018)
    target_width=np.quantile(perp[select],.9)-np.quantile(perp[select],.1)
    if target_width < min(buckets)*1.25:
        raise ValueError(f'candidate head grasp width {target_width:.1f}px not wider than shaft {min(buckets):.1f}px')
    target_px=pts[select].mean(0)+[X0,Y0]
    target_world=WristView(type('K',(),dict(center_x_px=640,center_y_px=360,focal_x_px=meta['camera']['fx'],focal_y_px=meta['camera']['fx']))(),
                           np.array(meta['top']['top_1']['cam_R']),np.array(meta['top']['top_1']['cam_t']),table_z).to_world(*target_px)
    return dict(head_end_widths_px=np.round(buckets,1).tolist(),width_ratio=round(ratio,2),
                target_width_px=round(target_width,1),
                center_px=np.round(c+[X0,Y0],1).tolist(), target_px=np.round(target_px,1).tolist(),
                target_world=np.round(target_world,1).tolist(),
                original_center=meta['top']['top_1']['xy'],length_px=round(length,1))

if __name__=='__main__':
    for run in sys.argv[1:]:
        d=Path('runs')/run/'item_001'; m=json.loads((d/'meta.json').read_text())
        print(run,head_target(Image.open(d/'top_1.jpg'),m['top']['top_1']['bbox'],m))
