"""Nut grasp from the metal-only mask: ring centre + across-flats jaw angle (image px)."""
import math
import numpy as np
from scipy import ndimage

def nut_grasp(rgb, bbox, m=40):
    x0,y0,x1,y1=bbox; X0,Y0=max(0,x0-m),max(0,y0-m)
    a=rgb[Y0:y1+m, X0:x1+m].astype(float)
    s=a.sum(-1); ch=(a[...,0]-a[...,2])/np.maximum(s,1)
    b=np.r_[ch[:4].ravel(),ch[-4:].ravel(),ch[:,:4].ravel(),ch[:,-4:].ravel()]
    bs=np.r_[s[:4].ravel(),s[-4:].ravel(),s[:,:4].ravel(),s[:,-4:].ravel()]
    # metal: low cardboard chroma AND not darker than the cardboard (shadow is darker, still orange-ish)
    fg=(ch<0.4*max(float(np.percentile(b,75)),0.08)) & (s>0.85*np.median(bs))
    fg=ndimage.binary_closing(ndimage.binary_opening(fg),iterations=3)
    fg=ndimage.binary_fill_holes(fg)
    lab,n=ndimage.label(fg)
    if n==0: return None
    k=1+int(np.argmax(ndimage.sum(fg,lab,range(1,n+1))))
    ys,xs=np.nonzero(lab==k)
    if len(xs)<800: return None
    cx,cy=xs.mean(),ys.mean()
    # width over angle; min = across flats (period 60)
    best=None
    for d in range(0,180,2):
        t=math.radians(d); p=(xs-cx)*math.cos(t)+(ys-cy)*math.sin(t)
        w=np.percentile(p,99)-np.percentile(p,1)
        if best is None or w<best[1]: best=(d,w)
    t=math.radians(best[0]); p=(xs-cx)*math.cos(t)+(ys-cy)*math.sin(t)
    wmax=max(np.percentile((xs-cx)*math.cos(math.radians(d))+(ys-cy)*math.sin(math.radians(d)),99)
             -np.percentile((xs-cx)*math.cos(math.radians(d))+(ys-cy)*math.sin(math.radians(d)),1) for d in range(0,180,10))
    round_ok = wmax/best[1] < 1.35            # nut-like (not shadow-elongated)
    return dict(c=(cx+X0,cy+Y0), close_deg_px=best[0], flats_px=best[1], round_ok=bool(round_ok), px=len(xs))
