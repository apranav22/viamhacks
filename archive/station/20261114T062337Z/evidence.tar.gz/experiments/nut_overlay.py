import json,io,base64,math,sys,glob
import numpy as np
from PIL import Image,ImageDraw
sys.path.insert(0,'/opt/viam/sorter-ali/exp')
from nut_center import nut_grasp
tiles=[]
for run in sys.argv[1:]:
  for d in sorted(glob.glob(f'/opt/viam/sorter-ali/runs/{run}/item_*')):
    try: m=json.load(open(d+'/meta.json'))
    except Exception: continue
    for k,v in (m.get('top') or {}).items():
      if not v.get('bbox'): continue
      im=Image.open(f'{d}/{k}.jpg').convert('RGB'); r=nut_grasp(np.asarray(im),v['bbox'])
      dr=ImageDraw.Draw(im); dr.rectangle(v['bbox'],outline='red',width=2)
      b=v['bbox']; cx,cy=(b[0]+b[2])/2,(b[1]+b[3])/2
      if r:
        cx,cy=r['c']; t=math.radians(r['close_deg_px']); L=r['flats_px']/2+25
        dr.line((cx-L*math.cos(t),cy-L*math.sin(t),cx+L*math.cos(t),cy+L*math.sin(t)),fill='lime',width=3)
        dr.ellipse((cx-5,cy-5,cx+5,cy+5),fill='yellow')
      c=im.crop((int(cx)-110,int(cy)-110,int(cx)+110,int(cy)+110))
      ImageDraw.Draw(c).text((3,3),f"{run[9:15]} {d[-3:]}/{k[-1]} {'ok' if r and r['round_ok'] else 'NO'}",fill='yellow')
      tiles.append(c)
s=Image.new('RGB',(220*6,220*((len(tiles)+5)//6)))
for i,t in enumerate(tiles): s.paste(t,(220*(i%6),220*(i//6)))
b=io.BytesIO(); s.save(b,'JPEG',quality=80); print('B64:'+base64.b64encode(b.getvalue()).decode())
