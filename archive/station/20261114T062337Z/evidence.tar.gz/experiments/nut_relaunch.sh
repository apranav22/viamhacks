#!/bin/bash
B=/opt/viam/sorter-ali; cd $B/current
for n in 6 7 8 9 10; do
  while pgrep -f "[p]ython3.12 -u $B/exp/nut_retries.py" >/dev/null; do sleep 2; done
  sleep 3
  PYTHONPATH=.:$B/exp $B/.venv/bin/python3.12 -u $B/exp/nut_retries.py > $B/nut$n.log 2>&1 < /dev/null
done
