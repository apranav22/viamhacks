"""hex_nut collect: metal-mask centre + across-flats jaws, retries turn 30 deg. sort.py unchanged on disk."""
import asyncio, io, math, sys, types
import numpy as np
from PIL import Image
src = open("sort.py").read()
for old, new in [('retries = 0 if self.args.mode == "collect" else G["retries"]', 'retries = G["retries"]'),
                 ('theta_extra += 90.0', 'theta_extra += 30.0')]:
    assert src.count(old) == 1, old
    src = src.replace(old, new)
mod = types.ModuleType("sort"); mod.__file__ = "sort.py"; sys.modules["sort"] = mod
exec(compile(src, "sort.py", "exec"), mod.__dict__)
from nut_center import nut_grasp
from pipeline import cam_to_world
from screws import WristView
orig = mod.Sorter.look
async def look(self, item, attempt, heading):
    new, tape = await orig(self, item, attempt, heading)
    if new is None: return new, tape
    r = nut_grasp(np.asarray(Image.open(io.BytesIO(self.top_image)).convert("RGB")), new[4])
    if r is None or not r["round_ok"]:
        print(f"  NUT mask not nut-like ({r and round(r['flats_px'])}); not descending", flush=True)
        return None, tape
    k = (await self.cam.get_properties()).intrinsic_parameters; rot, t = await cam_to_world(self.m)
    v = WristView(k, rot, t, mod.TZ)
    cx, cy = r["c"]; a = math.radians(r["close_deg_px"])
    x, y = v.to_world(cx, cy); x2, y2 = v.to_world(cx + 20 * math.cos(a), cy + 20 * math.sin(a))
    close_world = math.degrees(math.atan2(y2 - y, x2 - x))
    if math.dist((x, y), new[:2]) > 15:
        print(f"  NUT centre shift {math.dist((x, y), new[:2]):.1f} mm too big; not descending", flush=True)
        return None, tape
    yaw = close_world - mod.G["jaw_offset_deg"]          # pick() adds jaw_offset -> jaws close along close_world
    print(f"  NUT {new[0]:.1f},{new[1]:.1f} -> {x:.1f},{y:.1f}  close {close_world % 180:.0f} deg (flats {r['flats_px']:.0f} px)", flush=True)
    self.meta.setdefault("nut_grasp", {})[f"attempt_{attempt}"] = {"xy": [round(x, 1), round(y, 1)], "close_deg": round(close_world % 180, 1)}
    return (x, y, new[2], yaw, new[4]), tape
mod.Sorter.look = look
mod.HAND_FRAC = 1.1          # hand gate off (hung WATCH twice)
orig_place = mod.Sorter.place_back
async def place_back(self):
    await orig_place(self)
    for _ in range(2):        # shake off a nut stuck to a finger
        await self.gripper.grab(); await asyncio.sleep(0.3); await self.release()
mod.Sorter.place_back = place_back
sys.argv = ["sort.py", "--mode", "collect", "--background", "cardboard", "--label", "good", "--type", "hex_nut",
            "--reps", "20", "--assume-lying", "--watch-timeout", "300"]
asyncio.run(mod.main())
