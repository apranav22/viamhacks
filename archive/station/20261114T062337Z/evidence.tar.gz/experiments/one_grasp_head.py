"""One operator-approved head-biased grasp, in-memory only; instrument retention."""
import asyncio
import io
import math
import os
import sys
from pathlib import Path
from PIL import Image
import sort
from pipeline import Mover, cam_to_world
from screws import WristView
from station import connect
from viam.components.arm import Arm
from head_target_preview import head_target

original_look = sort.Sorter.look
original_grab = Mover.grab
original_straight = sort.Sorter.straight
original_outside_change = sort.outside_change
original_detect = sort.detect
watch_count = 0

def diagnosed_outside_change(rgb, ref, pad_px):
    global watch_count
    watch_count += 1
    result = original_outside_change(rgb, ref, pad_px)
    if watch_count % 30 == 0:
        print(f'WATCH GATE frame {watch_count}: hand_fraction={result:.4f} threshold={sort.HAND_FRAC}',flush=True)
    return result

def diagnosed_detect(rgb, view, region):
    result = original_detect(rgb, view, region)
    if region is not None and watch_count % 30 == 29:
        print(f'WATCH DETECT {[(round(i[0]),round(i[1]),round(i[3])) for i in result[:2]]}',flush=True)
    return result

sort.outside_change = diagnosed_outside_change
sort.detect = diagnosed_detect

async def head_look(self, item, attempt, heading):
    new, tape = await original_look(self, item, attempt, heading)
    if new is None:
        return new, tape
    props = (await self.cam.get_properties()).intrinsic_parameters
    rot, t = await cam_to_world(self.m)
    view = WristView(props, rot, t, sort.TZ)
    r = head_target(Image.open(io.BytesIO(self.top_image)), new[4], self.meta)
    if r['width_ratio'] < 1.35:
        raise RuntimeError(f"head/shaft not distinct (ratio {r['width_ratio']}); refusing to descend")
    target_world = view.to_world(*r['target_px'])
    center_world = view.to_world(*r['center_px'])
    x = new[0] + target_world[0] - center_world[0]
    y = new[1] + target_world[1] - center_world[1]
    delta = math.dist((x,y),new[:2])
    if not 7 < delta < 30 or not (150 < x < 400 and 200 < y < 500):
        raise RuntimeError(f"head target shift {delta:.1f} mm or XY {x:.1f},{y:.1f} outside bounds; refusing to descend")
    print(f"HEAD TARGET original {new[0]:.1f},{new[1]:.1f} -> {x:.1f},{y:.1f}; shift {delta:.1f} mm; "
          f"head widths {r['head_end_widths_px']} px, ratio {r['width_ratio']}", flush=True)
    self.meta['head_probe'] = {'target_xy': [round(x,1),round(y,1)], 'original_xy': [round(new[0],1),round(new[1],1)],
                               'width_ratio': r['width_ratio'], 'px':r['target_px']}
    return (x,y,*new[2:]), tape

async def measured_grab(self):
    pos = await original_grab(self)
    print(f"RETENTION settled grab / before lift: finger_pos={pos}", flush=True)
    return pos

async def measured_straight(self,x,y,z,label):
    if label.startswith('lift'):
        print(f"RETENTION at lift start: finger_pos={await self.mv.finger_pos()}",flush=True)
    await original_straight(self,x,y,z,label)
    if label.startswith('lift'):
        print(f"RETENTION after lift: finger_pos={await self.mv.finger_pos()}",flush=True)

sort.Sorter.look = head_look
sort.Sorter.straight = measured_straight
Mover.grab = measured_grab

async def run():
    if sort.G['min_table_clearance_mm'] != 2:
        raise RuntimeError('Baseline clearance changed; abort')
    sort.G = dict(sort.G,min_table_clearance_mm=1.0)
    reps = int(os.environ.get('HEAD_REPS', '1'))
    if not 1 <= reps <= 8:
        raise RuntimeError('Only 1-8 supervised head-grasp picks are permitted')
    sys.argv = ['sort.py','--mode','collect','--background','cardboard','--label','good',
                '--type','socket_thin_short','--reps',str(reps),'--watch-timeout','60']
    print(f'{reps} head-biased grasps at temporary 1 mm clearance; no persistent changes',flush=True)
    try:
        await sort.main()
    except BaseException:
        async with await connect() as m:
            try:
                await Arm.from_robot(m,'arm').stop()
            except Exception as e:
                print(f'ARM STOP FAILED: {e}; use E-stop',flush=True)
        raise

asyncio.run(run())
