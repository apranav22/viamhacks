"""Single operator-approved lower grasp test; no persistent config changes."""
import asyncio
import sys
import sort
from station import connect
from viam.components.arm import Arm

async def run():
    if sort.G['min_table_clearance_mm'] != 2:
        raise RuntimeError('Expected original clearance 2 mm; refusing unexpected baseline')
    sort.G = dict(sort.G, min_table_clearance_mm=1.0)
    sys.argv = ['sort.py', '--mode', 'collect', '--background', 'cardboard', '--label', 'good',
                '--type', 'socket_thin_short', '--reps', '1', '--watch-timeout', '30']
    print('SINGLE LOWER GRASP: clearance 1 mm; no persistent calibration edits', flush=True)
    try:
        await sort.main()
    except BaseException:
        async with await connect() as machine:
            await Arm.from_robot(machine, 'arm').stop()
        raise

asyncio.run(run())
