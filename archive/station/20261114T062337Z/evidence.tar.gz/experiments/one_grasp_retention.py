"""Operator-approved one-cycle grasp retention diagnosis; no persistent calibration change."""
import asyncio
import sys
import sort
from pipeline import Mover
from station import connect
from viam.components.arm import Arm

original_grab = Mover.grab
original_straight = sort.Sorter.straight

async def measured_grab(self):
    pos = await original_grab(self)
    print(f"RETENTION after settled grab, before lift: finger_pos={pos}", flush=True)
    return pos

async def measured_straight(self, x, y, z, label):
    if label.startswith("lift"):
        print(f"RETENTION immediately before lift: finger_pos={await self.mv.finger_pos()}", flush=True)
    await original_straight(self, x, y, z, label)
    if label.startswith("lift"):
        print(f"RETENTION immediately after lift: finger_pos={await self.mv.finger_pos()}", flush=True)

Mover.grab = measured_grab
sort.Sorter.straight = measured_straight

async def run():
    if sort.G["min_table_clearance_mm"] != 2:
        raise RuntimeError("Expected measured baseline clearance 2 mm; aborting")
    sort.G = dict(sort.G, min_table_clearance_mm=1.0)
    sys.argv = ["sort.py", "--mode", "collect", "--background", "cardboard", "--label", "good",
                "--type", "socket_thin_short", "--reps", "1", "--watch-timeout", "30"]
    print("ONE supervised grasp; 1 mm clearance in memory; finger readings before/after lift", flush=True)
    try:
        await sort.main()
    except BaseException:
        async with await connect() as machine:
            try:
                await Arm.from_robot(machine, "arm").stop()
            except Exception as error:
                print(f"ARM STOP FAILED: {error}; use E-stop", flush=True)
        raise

asyncio.run(run())
