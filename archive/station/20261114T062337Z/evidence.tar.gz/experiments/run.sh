B=/opt/viam/sorter-ali; cd $B/current
for cfg in "resnet18 0" "resnet18 1" "wide_resnet50_2 0" "wide_resnet50_2 1"; do set -- $cfg
  EXP_ROOT=$B/current EXP_DEVICE=xpu EXP_BACKBONE=$1 EXP_PER_TYPE=$2 PYTHONPATH=$B/current $B/.train-venv/bin/python3.12 $B/exp/exp_topcrop.py 2>&1 | grep -vE "Warning|warn|^ *$|if |TracerWarning"
done
