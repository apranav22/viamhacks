import json,sys,base64,io
sys.path.insert(0,'.')
from PIL import Image, ImageDraw
from vh.anomaly import part_crop
R='runs/20261113_173234_sort/'
tiles=[]
for i in range(1,14):
    d=R+f'item_{i:03d}/'
    try:
        m=json.load(open(d+'meta.json')); t=(m.get('top') or {}).get('top_1') or {}
        if t.get('bbox'): im,_=part_crop(d+'top_1.jpg',t['bbox'],out=220)
        else:
            im=Image.open(d+'watch.jpg').convert('RGB'); im=im.crop((300,100,1000,620)).resize((220,220))
    except Exception as e:
        im=Image.new('RGB',(220,220),'black')
    ImageDraw.Draw(im).text((4,4),f'#{i}',fill='yellow'); tiles.append(im)
s=Image.new('RGB',(220*7,440))
for k,t in enumerate(tiles): s.paste(t,(220*(k%7),220*(k//7)))
b=io.BytesIO(); s.save(b,'JPEG',quality=80); print('B64:'+base64.b64encode(b.getvalue()).decode())
