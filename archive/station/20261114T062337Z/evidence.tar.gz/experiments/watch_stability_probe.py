"""Read-only reproduction of sort.watch conditions; no motion."""
import asyncio, math, time
import numpy as np
from viam.components.camera import Camera
from station import connect
from pipeline import cam_to_world
from screws import WristView, color_frame, detect
from sort import outside_change, zone_px, ZONES, STABLE_MM, STABLE_DEG, STILL_S, HAND_FRAC
async def main():
    async with await connect() as m:
        cam=Camera.from_robot(m,'cam');k=(await cam.get_properties()).intrinsic_parameters;rot,t=await cam_to_world(m)
        view=WristView(k,rot,t,6.5);zone=ZONES['cardboard'];px=zone_px(view,zone)
        ref=await color_frame(cam,True);last=None;since=None
        print('zone',zone,px,flush=True)
        for i in range(30):
            rgb=await color_frame(cam,True)
            items=sorted(detect(rgb,view,zone),key=lambda it:-it[2]);it=items[0] if items else None
            h=outside_change(rgb,ref,px)
            same=bool(it and last and math.dist(it[:2],last[:2])<STABLE_MM and abs((it[3]-last[3]+90)%180-90)<STABLE_DEG)
            since=(since or time.monotonic()) if same else None
            if i%2==0 or not it:
                print(i,'item',it[:4] if it else None,'hand_frac',round(h,3),'same',same,'still',round(time.monotonic()-since,2) if since else None,flush=True)
            last=it
asyncio.run(main())
