"""Read-only wrist watch detection threshold sweep; no arm motion."""
import asyncio
from viam.components.camera import Camera
from station import connect
from pipeline import cam_to_world
import screws
from screws import WristView, color_frame, detect

async def main():
    async with await connect() as m:
        cam=Camera.from_robot(m,'cam')
        k=(await cam.get_properties()).intrinsic_parameters
        rot,t=await cam_to_world(m)
        view=WristView(k,rot,t,6.5)
        rgb=await color_frame(cam,True)
        zone=dict(x_min=150,x_max=400,y_min=200,y_max=500)
        for threshold in (70,60,50,45,40,35,30):
            screws.COLOR_DIFF=threshold
            for minpix in (40,20):
                screws.MIN_PIXELS=minpix
                rows=detect(rgb,view,zone)
                print(threshold,minpix,[(tuple(round(n,1) for n in r[:2]),r[2],round(r[3]),r[4]) for r in rows],flush=True)

asyncio.run(main())
