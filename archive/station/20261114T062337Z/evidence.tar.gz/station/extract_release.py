import hashlib,json,tarfile
from pathlib import Path
base=Path('/opt/viam/sorter-ali');parts=base/'parts'
manifest=json.loads((parts/'manifest.json').read_text())
archive=base/'joined-release.tar.gz'
with archive.open('xb') as out:
 for entry in manifest['parts']:
  p=parts/entry['name'];data=p.read_bytes()
  if len(data)!=entry['size'] or hashlib.sha256(data).hexdigest()!=entry['sha256']:raise RuntimeError('Shard integrity failure: '+p.name)
  out.write(data)
if hashlib.sha256(archive.read_bytes()).hexdigest()!=manifest['archive_sha256']:raise RuntimeError('Archive SHA256 mismatch')
release=base/'releases'/'20261113_1647';release.mkdir(parents=True,exist_ok=False)
with tarfile.open(archive) as tar:tar.extractall(release,filter='data')
files=json.loads((release/'DEPLOYMENT_MANIFEST.json').read_text())['files']
for name,digest in files.items():
 if hashlib.sha256((release/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('Release integrity failure: '+name)
(base/'ACTIVE_RELEASE').write_text(str(release)+'\n')
print(json.dumps({'release':str(release),'verified_files':len(files),'archive_sha256':manifest['archive_sha256']}))
