#!/usr/bin/env bash
# Isolated per-team environments only; never apt install, change drivers, restart Viam or launch motion.
set -euo pipefail
BASE=/opt/viam/sorter-ali
umask 077
trap 'rc=$?; printf "%s\n" "$rc" > "$BASE/setup.exit"' EXIT
printf 'installing runtime\n' > "$BASE/setup.stage"
"$BASE/.venv/bin/python3.12" -m pip install --disable-pip-version-check --no-cache-dir openvino==2026.4.1 viam-sdk==0.85.2 numpy pillow scipy python-dotenv opencv-python-headless
"$BASE/.venv/bin/python3.12" - <<'PY'
import json,openvino as ov
from pathlib import Path
core=ov.Core()
r={'openvino':ov.__version__,'devices':[{"name":d,"full_name":core.get_property(d,'FULL_DEVICE_NAME')} for d in core.available_devices]}
Path('/opt/viam/sorter-ali/runtime_ready.json').write_text(json.dumps(r,indent=2));print(r,flush=True)
PY
printf 'installing XPU training environment\n' > "$BASE/setup.stage"
/bin/python3.12 -m venv --without-pip "$BASE/.train-venv"
"$BASE/.train-venv/bin/python3.12" "$BASE/get-pip.py" --disable-pip-version-check
"$BASE/.train-venv/bin/python3.12" -m pip install --disable-pip-version-check --no-cache-dir torch==2.15.0+xpu torchvision==0.29.2+xpu --index-url https://download.pytorch.org/whl/xpu
"$BASE/.train-venv/bin/python3.12" -m pip install --disable-pip-version-check --no-cache-dir anomalib==2.7.0 openvino==2026.4.1
"$BASE/.train-venv/bin/python3.12" - <<'PY'
import json,torch
from pathlib import Path
r={'torch':torch.__version__,'xpu_available':torch.xpu.is_available(),'device_count':torch.xpu.device_count()}
if r['xpu_available']:
    r['device_name']=torch.xpu.get_device_name(0)
    x=torch.arange(1024,dtype=torch.float32,device='xpu');r['tensor_sum']=float(x.sum().cpu());torch.xpu.synchronize()
Path('/opt/viam/sorter-ali/training_ready.json').write_text(json.dumps(r,indent=2));print(r,flush=True)
PY
printf 'complete\n' > "$BASE/setup.stage"
