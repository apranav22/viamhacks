#!/usr/bin/env bash
set -uo pipefail
cd /opt/viam/sorter-ali/releases/20261113_1647
/opt/viam/sorter-ali/.train-venv/bin/python3.12 train_anomaly.py --runs runs/20261113_153347_collect runs/20261113_153544_collect --type button_ss_long --background white --train-device xpu --out models/button_xpu_v2
rc=$?
printf '%s\n' "$rc" > xpu_train_v2.exit
exit "$rc"
